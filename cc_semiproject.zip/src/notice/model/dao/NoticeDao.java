package notice.model.dao;

import java.sql.Connection;
import java.util.List;

import notice.model.vo.Notice;

public class NoticeDao {

	public List<Notice> selectList(Connection con) {
		// TODO Auto-generated method stub
		return null;
	}

	public Notice selectNotice(Connection con, int n_no) {
		// TODO Auto-generated method stub
		return null;
	}

	public int insertNotice(Connection con, Notice notice) {
		// TODO Auto-generated method stub
		return 0;
	}

}
