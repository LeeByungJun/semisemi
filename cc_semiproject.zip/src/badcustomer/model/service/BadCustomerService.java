package badcustomer.model.service;

public class BadCustomerService {

}
