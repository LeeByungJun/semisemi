package badcustomer.model.dao;

public class BadCustomerDao {

}
